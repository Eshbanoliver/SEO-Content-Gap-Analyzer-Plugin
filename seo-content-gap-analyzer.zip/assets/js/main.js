jQuery(function($){
  $('#sg-fetch').on('click', function(){
    $.post(SGAjax.ajax_url, {
      action: 'sg_fetch_data',
      nonce: SGAjax.nonce
    }, function(res){
      if(res.success){
        const ctx = document.getElementById('sg-topic-chart').getContext('2d');
        new Chart(ctx, {
          type: 'bar',
          data: {
            labels: res.data.topics,
            datasets: [{
              label: 'Keyword Gap',
              data: res.data.gaps,
              backgroundColor: 'rgba(54, 162, 235, 0.5)'
            }]
          }
        });
      } else {
        alert('Error: ' + res.data);
      }
    });
  });
});
