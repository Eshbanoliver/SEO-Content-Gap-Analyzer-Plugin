<?php
/*
Plugin Name: SEO Content Gap Analyzer
Description: Identify competitor content & keyword gaps with recommendations and visuals.
Version: 1.0
Author: Your Name
Text Domain: seo-gap-analyzer
*/

if (!defined('ABSPATH')) exit;

class SEO_Gap_Analyzer {
  public function __construct(){
    add_action('admin_menu', [$this,'add_admin_page']);
    add_action('admin_enqueue_scripts', [$this,'enqueue_assets']);
    add_action('wp_ajax_sg_fetch_data', [$this,'ajax_fetch_data']);
  }

  public function add_admin_page(){
    add_menu_page('SEO Gap Analyzer', 'SEO Gap Analyzer', 'manage_options', 'seo-gap-analyzer', [$this,'render_dashboard'], 'dashicons-chart-area', 56);
  }

  public function enqueue_assets($hook){
    if ($hook !== 'toplevel_page_seo-gap-analyzer') return;
    wp_enqueue_script('sg-charts', 'https://cdn.jsdelivr.net/npm/chart.js', [], null, true);
    wp_enqueue_script('sg-main', plugin_dir_url(__FILE__) . 'assets/js/main.js', ['jquery','sg-charts'], null, true);
    wp_enqueue_style('sg-style', plugin_dir_url(__FILE__) . 'assets/css/style.css');
    wp_localize_script('sg-main', 'SGAjax', ['ajax_url' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('sg_nonce')]);
  }

  public function render_dashboard(){
    echo '<div class="wrap"><h1>SEO Content Gap Analyzer</h1><canvas id="sg-topic-chart" width="400" height="200"></canvas><button id="sg-fetch">Analyze Now</button></div>';
  }

  public function ajax_fetch_data(){
    check_ajax_referer('sg_nonce', 'nonce');
    $data = ['topics' => ['Topic A', 'Topic B'], 'gaps' => [5, 3]];
    wp_send_json_success($data);
  }
}

new SEO_Gap_Analyzer();
?>
